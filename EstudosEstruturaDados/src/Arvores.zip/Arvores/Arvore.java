package Arvores;

public class Arvore {
	No raiz;
	
	public Arvore() {
		this.raiz=null;
	}
	
	public void insere(int info) {
		
	}
	
}
